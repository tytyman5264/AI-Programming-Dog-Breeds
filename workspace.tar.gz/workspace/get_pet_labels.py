from os import listdir
import os

def parsefilenames(name):
    # Sets pet_image variable to a filename 
    pet_image = name

    # Sets string to lower case letters
    low_pet_image = pet_image.lower()

    # Remove file extensions
    remove_extension = os.path.splitext(name)
    
    # Splits lower case string by _ to break into words 
    word_list_pet_image = remove_extension[0].split("_")

    # Create pet_name starting as empty string
    pet_name = ""

    # Loops to check if word in pet name is only
    # alphabetic characters - if true append word
    # to pet_name separated by trailing space 
    for word in word_list_pet_image:
        if word.isalpha():
            pet_name += word + " "

    # Strip off starting/trailing whitespace characters 
    pet_name = pet_name.strip()

    # Prints resulting pet_name
    print("\nFilename =", pet_image, "   Label =", pet_name)
    
    return pet_name

def get_pet_labels(image_dir):

    files = listdir(image_dir)
    
    pet_labels = []
    
    for item in files:
        if item[0] != ".":
            label = parsefilenames(item)
            pet_labels.append(label)
        
    results_dic = {}
    
    items_in_dic = len(results_dic)
    print("\nEmpty Dictionary results_dic - n items=", items_in_dic)

    
    filenames = files
    
    for idx in range(0, len(filenames), 1):
        if item[0] != ".":
            label = parsefilenames(item)
            pet_labels.append(label)
        if filenames[idx] not in results_dic:
            results_dic[filenames[idx]] = [pet_labels[idx]]
        else:
            print("** Warning: Key=", filenames[idx], 
                "already exists in results_dic with value =", 
                 results_dic[filenames[idx]])

    print("\nPrinting all key-value pairs in dictionary results_dic:")
    for key in results_dic:
        print("Filename=", key, "   Pet Label=", results_dic[key][0])
    # Replace None with the results_dic dictionary that you created with this function
    return results_dic
