def calculates_results_stats(results_dic):
    
    results_stats_dic = {}
    
    Z = len(results_dic)
    A = 0
    B = 0 
    C = 0
    E = 0
    Y = 0
    for key in results_dic:
        if results_dic[key][3] == 1 and results_dic[key][4] == 1:
            A += 1
        if results_dic[key][3] == 1:
            B += 1
        if results_dic[key][3] == 0 and results_dic[key][4] == 0:
            C += 1
        if results_dic[key][3] == 1 and results_dic[key][2] == 1:
            E += 1
        if results_dic[key][2] == 1:
            Y += 1
       
    D = Z - B
    
    results_stats_dic["n_images"] = Z
    results_stats_dic["n_dogs_img"] = B
    results_stats_dic["n_notdogs_img"] = D
    results_stats_dic["n_match"] = Y
    results_stats_dic["n_correct_dogs"] = A
    results_stats_dic["n_correct_notdogs"] = C
    results_stats_dic["n_correct_breed"] = E
    
    if D > 1:
        results_stats_dic["pct_match"] =  Y/Z * 100
        results_stats_dic["pct_correct_dogs"] = A/B * 100
        results_stats_dic["pct_correct_breed"] = E/B * 100
        results_stats_dic["pct_correct_notdogs"] = C/D * 100
        
    return results_stats_dic
