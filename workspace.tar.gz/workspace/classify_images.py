#!/usr/bin/env python3
# -*- coding: utf-8 -*-
# */AIPND-revision/intropyproject-classify-pet-images/classify_images.py
#                                                                             
# PROGRAMMER: 
# DATE CREATED:                                 
# REVISED DATE: 
# PURPOSE: Create a function classify_images that uses the classifier function 
#          to create the classifier labels and then compares the classifier 
#          labels to the pet image labels. This function inputs:
#            -The Image Folder as image_dir within classify_images and function 
#             and as in_arg.dir for function call within main. 
#            -The results dictionary as results_dic within classify_images 
#             function and results for the functin call within main.
#            -The CNN model architecture as model wihtin classify_images function
#             and in_arg.arch for the function call within main. 
#           This function uses the extend function to add items to the list 
#           that's the 'value' of the results dictionary. You will be adding the
#           classifier label as the item at index 1 of the list and the comparison 
#           of the pet and classifier labels as the item at index 2 of the list.
#
##
# Imports classifier function for using CNN to classify images 
from classifier import classifier 

def classify_images(images_dir, results_dic, model):
    idx = 0
    for each in results_dic:
        #create file directory + filename string
        file_results = images_dir + each
        #save pet label list in a variable
        pet_label_list = results_dic[each]
        #run image classifier function and get comma-separated string
        image_classification = classifier(file_results, model)
        #format lowercase for image classification
        image_classification = image_classification.lower()
        #Putting each item of variable inside a list separated by a comma
        split_label = image_classification.split(",")
        #strip whitespaces
        image_classification = image_classification.strip()
        #save pet label in a variable
        pet_label = pet_label_list[0]
        match = 0
        for label in split_label:
            if label.strip() == pet_label:
                match = 1             
                break 
        pet_label_list.append(image_classification)
        pet_label_list.append(match)
        
        print(idx, " : ", image_classification)
        idx += 1
        
    return None 